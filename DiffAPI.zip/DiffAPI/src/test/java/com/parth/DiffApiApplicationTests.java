package com.parth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiffApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
